This folder contains gazetteers (lists of places with their coordinates and other metadata) for the Gaza project:

* geonames_gaza_selection: a selection of places in Gaza, from the geonames website
  (https://download.geonames.org/export/dump/PS.zip).
* countries.tsv: a coordinate pair for each country in the world. Coordinates from geonames.